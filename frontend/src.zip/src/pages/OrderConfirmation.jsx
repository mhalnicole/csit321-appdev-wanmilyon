import { useNavigate } from "react-router-dom";
import "../css/OrderConfirmation.css";

export default function OrderConfirmation() {
    const navigate = useNavigate();

    const order = {
        customer: "Matthew Pasaol",
        orderNo: "#1001",
        items: [
            { name: "Chicken Burger", qty: 2, price: 150 },
            { name: "French Fries", qty: 1, price: 90 },
            { name: "Iced Tea", qty: 2, price: 50 }
        ],
        instructions: "No onions, extra ketchup.",
        payment: "Cash on Delivery",
        total: 490
    };

    return (
        <div className="confirmation-container">

            <h1>ðŸŽ‰ Order Confirmed!</h1>

            <p>
                Thank you for your order.
            </p>

            <div className="confirmation-card">

                <h3>Order Information</h3>

                <p><strong>Order Number:</strong> {order.orderNo}</p>

                <p><strong>Customer:</strong> {order.customer}</p>

                <p><strong>Payment:</strong> {order.payment}</p>

                <hr />

                <h3>Items Ordered</h3>

                {order.items.map((item, index) => (

                    <div key={index} className="order-item">

                        <span>
                            {item.qty} x {item.name}
                        </span>

                        <span>
                            â‚±{item.price * item.qty}
                        </span>

                    </div>

                ))}

                <hr />

                <h3>Special Instructions</h3>

                <p>{order.instructions}</p>

                <hr />

                <h2>Total: â‚±{order.total}</h2>

                <button
                    onClick={() => navigate("/menu")}
                    className="back-btn"
                >
                    Back to Menu
                </button>

            </div>

        </div>
    );
}
