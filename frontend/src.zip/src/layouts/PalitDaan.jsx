import Sidebar from '../components/Sidebar';
import Navbar from '../components/Navbar';
import MainContent from '../layouts/MainContent';
import { useState } from 'react';

export default function PalitDaan() {   
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);

    const toggleSidebar = () => {
        setIsSidebarOpen(!isSidebarOpen);
    };

    return (
        <div style={{
            display: 'flex',
            flexDirection: 'column',
            minHeight: '100vh',
            fontFamily: 'system-ui, -apple-system, sans-serif',
            backgroundColor: '#ffa07a' 
        }}>
            <Navbar toggleSidebar={toggleSidebar} />
            <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
                {isSidebarOpen && <Sidebar />}
                <div style={{ flex: 1, overflowY: 'auto' }}>
                    <MainContent />
                </div>
            </div>
        </div>
    );
}